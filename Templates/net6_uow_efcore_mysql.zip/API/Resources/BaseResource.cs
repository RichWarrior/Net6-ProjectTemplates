﻿namespace $safeprojectname$
{
    /// <summary>
    /// 
    /// </summary>
    public class BaseResource
    {
    }
}
