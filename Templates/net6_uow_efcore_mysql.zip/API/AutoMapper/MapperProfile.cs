﻿using AutoMapper;

namespace $safeprojectname$.AutoMapper
{
    /// <summary>
    /// 
    /// </summary>
    public class MapperProfile :Profile
    {
    }
}
