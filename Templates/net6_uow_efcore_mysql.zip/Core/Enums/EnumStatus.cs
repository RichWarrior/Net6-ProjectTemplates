﻿namespace $safeprojectname$.Enums
{
    public enum EnumStatus
    {
        Passive,
        Active
    }
}
