﻿namespace $safeprojectname$.Utilities
{
    /// <summary>
    /// 
    /// </summary>
    public static class Messages
    {
        /// <summary>
        /// 
        /// </summary>
        public static string Successful => "Successful";
        /// <summary>
        /// 
        /// </summary>
        public static string Error => "Error";
        /// <summary>
        /// 
        /// </summary>
        public static string UnAuthorized => "UnAuthorized";
    }
}
