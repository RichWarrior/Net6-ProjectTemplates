﻿namespace $safeprojectname$.Utilities
{
    /// <summary>
    /// 
    /// </summary>
    public static class Regexs
    {
    }
}
